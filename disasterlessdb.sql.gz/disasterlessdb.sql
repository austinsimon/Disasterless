-- Database Manager 4.2.5 dump

SET NAMES utf8;
SET time_zone = '+00:00';
SET foreign_key_checks = 0;
SET sql_mode = 'NO_AUTO_VALUE_ON_ZERO';

DELIMITER ;;

DROP PROCEDURE IF EXISTS `SdArticle`;;
CREATE PROCEDURE `SdArticle`()
BEGIN
	SELECT 
		id,
        title,
        content,
        tag,
        photo_file_name,
        time_created
	FROM article;
END;;

DROP PROCEDURE IF EXISTS `SdAssistance`;;
CREATE PROCEDURE `SdAssistance`()
BEGIN
	SELECT id, content, assistance_type, phone_number, date_created
	FROM assistance
    ORDER BY date_created DESC;
END;;

DROP PROCEDURE IF EXISTS `SdBlockedRoad`;;
CREATE PROCEDURE `SdBlockedRoad`()
BEGIN
	SELECT 
		id,
        lat,
        lng
	FROM blocked_road;
END;;

DROP PROCEDURE IF EXISTS `SdOutage`;;
CREATE PROCEDURE `SdOutage`()
BEGIN
	SELECT
		id,
        lat,
        lng,
        radius,
        disaster_id
	FROM outage;
END;;

DROP PROCEDURE IF EXISTS `SdSupplies`;;
CREATE PROCEDURE `SdSupplies`(disasterId BIGINT)
BEGIN
	SELECT
		id,
        supply_name,
        supply_amount,
        lat,
        lng,
        disaster_id,
        address
	FROM supplies
    WHERE disaster_id = disasterId;
END;;

DROP PROCEDURE IF EXISTS `SlArticle`;;
CREATE PROCEDURE `SlArticle`(id BIGINT)
BEGIN
	SELECT 
		id,
        title,
        content,
        tag,
        photo_file_name,
        time_created
	FROM article AS a
    WHERE a.id = id;
END;;

DROP PROCEDURE IF EXISTS `SlDonationLink`;;
CREATE PROCEDURE `SlDonationLink`()
BEGIN
	SELECT link FROM donation_link WHERE id = 1;
END;;

DROP PROCEDURE IF EXISTS `SlUser`;;
CREATE PROCEDURE `SlUser`(email VARCHAR(255))
BEGIN
	SELECT 
		id,
        email,
        first_name,
        last_name,
        `password`,
        create_time
	FROM user
    WHERE email = email;
END;;

DROP PROCEDURE IF EXISTS `SsArticle`;;
CREATE PROCEDURE `SsArticle`(
id BIGINT,
title VARCHAR(45),
content LONGTEXT,
tag VARCHAR(45),
photo_file_name VARCHAR(255)
)
BEGIN
	IF id = 0 THEN
		INSERT INTO article
		SET title = title,
			content = content,
			tag = tag,
			photo_file_name = photo_file_name;
	ELSEIF photo_file_name != "" THEN
		UPDATE article
		SET title = title,
			content = content,
			tag = tag,
			photo_file_name = photo_file_name
		WHERE id = id;
	ELSE 
		UPDATE article
		SET title = title,
			content = content,
			tag = tag
		WHERE id = id;
    END IF;
END;;

DROP PROCEDURE IF EXISTS `SsAssistance`;;
CREATE PROCEDURE `SsAssistance`(content TEXT(2000), assistance_type VARCHAR(10), phone_number VARCHAR(20))
BEGIN
	INSERT INTO assistance
    SET 
		content = content,
        assistance_type = assistance_type,
        phone_number = phone_number;
END;;

DROP PROCEDURE IF EXISTS `SsBlockedRoad`;;
CREATE PROCEDURE `SsBlockedRoad`(lat DECIMAL(11,6), lng DECIMAL(11,6))
BEGIN
	INSERT INTO blocked_road
    SET lat = lat, lng = lng;
END;;

DROP PROCEDURE IF EXISTS `SsDonationLink`;;
CREATE PROCEDURE `SsDonationLink`(link VARCHAR(200))
BEGIN
	UPDATE donation_link SET link = link;
END;;

DROP PROCEDURE IF EXISTS `SsOutage`;;
CREATE PROCEDURE `SsOutage`(lat DECIMAL(15,10), lng DECIMAL(15,10), radius DECIMAL(15,10), disaster_id BIGINT)
BEGIN
	INSERT INTO outage
    SET lat = lat, lng = lng, radius = radius, disaster_id = disaster_id;
END;;

DROP PROCEDURE IF EXISTS `SsSupplies`;;
CREATE PROCEDURE `SsSupplies`(supplyName VARCHAR(45), supplyAmount VARCHAR(45), lat DECIMAL(11,6), lng DECIMAL(11,6), disasterId BIGINT, address VARCHAR(100))
BEGIN
	INSERT INTO supplies
    SET supply_name = supplyName, supply_amount = supplyAmount, lat = lat, lng = lng, disaster_id = disasterId, address = address;
END;;

DROP PROCEDURE IF EXISTS `SsUser`;;
CREATE PROCEDURE `SsUser`(email VARCHAR(255),
`password` VARCHAR(255),
first_name VARCHAR(20),
last_name VARCHAR(20))
BEGIN
	INSERT INTO user 
    SET 
		email = email,
        `password` = `password`,
        first_name = first_name,
        last_name = last_name;
END;;

DROP PROCEDURE IF EXISTS `SxBlockedRoadAll`;;
CREATE PROCEDURE `SxBlockedRoadAll`()
BEGIN
	DELETE FROM blocked_road;
END;;

DROP PROCEDURE IF EXISTS `SxOutageAll`;;
CREATE PROCEDURE `SxOutageAll`()
BEGIN
	DELETE FROM outage;
END;;

DROP PROCEDURE IF EXISTS `SxSuppliesAll`;;
CREATE PROCEDURE `SxSuppliesAll`()
BEGIN
	DELETE FROM supplies;
END;;

DELIMITER ;

DROP TABLE IF EXISTS `article`;
CREATE TABLE `article` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `title` varchar(45) DEFAULT NULL,
  `photo_file_name` varchar(255) DEFAULT NULL,
  `tag` varchar(45) DEFAULT NULL,
  `content` longtext,
  `time_created` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `article` (`id`, `title`, `photo_file_name`, `tag`, `content`, `time_created`) VALUES
(1,	'How to Prepare for a Flood',	'flood.jpg',	'Flood',	'Floods are one of the most common natural disasters seen in the United States. Flooding could be just the covering of water normally on dry land, but it could get to the devastating point of covering your house. Flooding could occur during any season, although if you are near coastal areas it may occur more often and especially during hurricane season. Floodings are formed in several ways such as excessive rain or snowmelt, waterways being blocked due to debris or overflow, or strong winds from tropical storms or hurricanes that cause a storm surge pushing water upon the land. The effects of a flooding could be detrimental. Transportation could be disrupted, drinking water could be polluted, it can cause landslides to occur, and cause fatalities and serious injuries. Procedures can be taken to protect yourself from a flood.\r\n\r\nWarnings\r\nWhether it be a watch, warning or evacuation matters can be taken by being signed up on the emergency notification. There are different types of warnings/watches. A flood watch means you are in an area of possible flooding. When on a flood watch/ flash flood watch be prepared to move to higher ground immediately upon short notice. To be updated sign up for the National Oceanic and Atmospheric Administration. The next one is a flood warning/ flash flood warning meaning that a flooding is about to occur soon. It is of high priority to move away from your area and moving to a better location.\r\n\r\nIn the event of a Flood\r\nIf there is flood water on the road already please do not attempt to cross it. The depth of the water is always not obvious. Walking through moving water can have an impactful effect on you. There is the possibility of six inches of moving water to have the ability to knock you off of your feet, and at least a foot of moving water could sweep a vehicle. If you are trapped in a building seek the highest ground possible, however, do not go to a high enclosed area because you can be trapped by rising floodwater. If you are trapped in a building call 911 if possible as well go to the roof if possible and signal for help. If you are trapped in a vehicle stay in the vehicle. Although, if water is rising in the vehicle seek a way to get on top of the roof of the car. If you are outside experiencing this seek higher ground, or climb sturdy objects.     \r\n\r\nAfter a flood\r\nIf your house was severely flooded from the event, do not go in until officials give you the â€œall clearâ€. Although if it is necessary that you have to enter a building after the event of a flood takes extreme cautions. Some safety considerations that you need to take in to protect yourself are from electric shock, mold contamination, lead paint, etc. Immediately shut off utilities to a flooded home or building to prevent electric shocks. Do not touch any wet electrical types of equipment. When outside stay away from moving water, watch out for dangerous debris, avoid wading in floodwater, and stay away from downed power lines.\r\n',	'2018-03-02 00:34:44'),
(2,	'How To Prepare For a Hurricane',	'hurricane.jpg',	'Hurricane',	'If the notice of a hurricane is coming your way it is necessary to take immediate actions in order to get yourself to safety. Hurricanes are one of the most devastating natural disasters that will ruin you if you are not prepared. The threats seen from hurricanes are high winds, heavy rainfall, storm surge, flooding, and tornadoes. The effects of a hurricane are catastrophic if not the correct precautions are taken. Many will be injured, a mass amount will be killed, and the majority of people will be left without homes. There are three procedures you must take into account when preparing for a hurricane. Those are the Now, During, and After stages.\r\n\r\nHow to Prepare Now\r\nThere is always action you can do in order to prepare beforehand for a hurricane. Your safety is always number one priority. Sign up for the local alerts and warnings to be constantly updated on the weather reports. There are different types of warnings and watches. First, it is hurricane advisory where there are expected conditions that may cause inconveniences if not the proper caution is taken. The next one is the hurricane watch where a possible tropical storm or hurricane is possible within the next 48 hours. Within the hurricane watch monitor the news and check if your emergency supplies need to be stocked. After hurricane watch, the next one is hurricane warning where within the next 36 hours a hurricane will for sure hit your location. At that moment make sure you have completed your storm preparations, and immediately left the threatened area. As well check local news to see if where you live needs to take action of leaving to the nearest hurricane shelter. You do not want to stay in your house knowing that it may be destroyed by the effects of the hurricane. If your house is in a safe location these are the procedures that you need to take to prepare. First stock up on emergency supplies. Gather plenty of Non-perishable foods and plenty of water. Board your windows with plywood so then the high winds can not shatter your windows. Remove all movable objects from outside to a safer location due to the fact that the strong wind will toss the objects at your window and may break it. As well it is important to gather all critical paperwork such as your financial and medical paperwork.\r\n\r\nDuring the hurricane\r\nIf you are in an area that will end up being flooded by the hurricane move to a higher ground before flood waters reach you. At all times during a hurricane stay indoors and away from windows and glass doors. Make sure you are in a sturdy building and in an area that is not likely to flood. Do not use a generator, gasoline-powered equipment tools, grill, camp stove, or charcoal-burning devices inside. Keep these items away to prevent possible inside fires.\r\n\r\nPost-Hurricane\r\nDo not wade in floodwaters due to possible dangerous debris like broken glass, dead animals, sewage, power lines, etc. Do not enter a building unless inspections have been done. This is because of the possibilities of a damaged electrical system, gas lines, and water lines may injure you. Wear protective gear when walking through such as rubber boots, masks, and gloves. Do not touch any wet electrical types of equipment or else you will be electrocuted. To clean up your house after a hurricane throws out any food that has been exposed or not maintained at proper temperature. Avoid drinking tap water unless you know it is safe. For safety measures boil or purify it. Disinfect everything because it may contain bacteria, chemicals, or sewage. Move out any porous materials, and air out your house.\r\n',	'2018-03-02 02:05:02'),
(3,	'Preparing for a Tornado',	'tornado.jpg',	'Tornado',	'Just like a hurricane, tornadoes are one of the most violent storms and cause deaths and injuries within seconds. What is common in the creation of a tornado is lightning or hail in a thunderstorm. Tornadoes can happen during any season but, is mainly seen during the seasons of spring and summer. The impact of a tornado varies. It can be light and only cause minor injuries and scale up to being catastrophic killing many lives. Procedures can be taken in order to prepare yourself for a situation of a tornado.',	'2018-03-02 02:09:11');

DROP TABLE IF EXISTS `assistance`;
CREATE TABLE `assistance` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `content` text,
  `assistance_type` varchar(10) DEFAULT NULL,
  `phone_number` varchar(20) DEFAULT NULL,
  `date_created` datetime DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `assistance` (`id`, `content`, `assistance_type`, `phone_number`, `date_created`) VALUES
(4,	'Extra water available for those in need. Contact number listed.',	'offer',	'(540)630-2975',	'2018-03-02 07:54:35'),
(5,	'In need to garbage bags to clean up street.',	'request',	'(142)854-3214',	'2018-03-02 07:55:06'),
(6,	'In need of someone who can remove large tree remains.',	'request',	'(601)248-1186',	'2018-03-02 07:56:11'),
(7,	'Have food left over from the storm.',	'offer',	'(336)418-2426',	'2018-03-02 07:58:05'),
(8,	'Retired fireman that knows how to remove damaged powerlines.',	'offer',	'(329)449-2247',	'2018-03-02 08:01:38'),
(9,	'Tree has fallen into houe. Need help making repairs.',	'request',	'(953)369-1953',	'2018-03-02 08:02:17');

DROP TABLE IF EXISTS `blocked_road`;
CREATE TABLE `blocked_road` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lat` decimal(11,6) DEFAULT NULL,
  `lng` decimal(11,6) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `blocked_road` (`id`, `lat`, `lng`) VALUES
(24,	28.580517,	-81.409412),
(25,	28.616689,	-81.384693),
(26,	28.551570,	-81.379200),
(27,	28.628744,	-81.243244),
(28,	28.646823,	-81.542622),
(29,	28.448986,	-81.399799),
(30,	28.546745,	-81.224018),
(31,	28.832258,	-81.321522),
(32,	28.290691,	-81.237751);

DROP TABLE IF EXISTS `donation_link`;
CREATE TABLE `donation_link` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `link` varchar(200) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `donation_link` (`id`, `link`) VALUES
(1,	'https://www.gofundme.com/stonemandouglasvictimsfund');

DROP TABLE IF EXISTS `outage`;
CREATE TABLE `outage` (
  `id` bigint(20) NOT NULL AUTO_INCREMENT,
  `lat` decimal(15,10) NOT NULL,
  `lng` decimal(15,10) NOT NULL,
  `radius` decimal(15,10) NOT NULL,
  `disaster_id` bigint(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `outage` (`id`, `lat`, `lng`, `radius`, `disaster_id`) VALUES
(18,	28.5480704047,	-81.2615555283,	5596.0543202920,	1),
(19,	28.5112711753,	-81.2924545761,	2704.5551550551,	1),
(20,	28.5613391046,	-81.3247269150,	4661.5491516743,	1),
(21,	28.4593684796,	-81.4888351913,	2770.8542241813,	1),
(22,	28.4352190015,	-81.4709824081,	1569.0554628056,	1),
(23,	28.4557464095,	-81.4448898788,	1249.9961273311,	1),
(24,	28.6939955333,	-81.5370941581,	3461.0292019831,	1);

DROP TABLE IF EXISTS `supplies`;
CREATE TABLE `supplies` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `supply_name` varchar(45) NOT NULL,
  `supply_amount` varchar(45) NOT NULL,
  `lat` decimal(11,6) NOT NULL,
  `lng` decimal(11,6) NOT NULL,
  `disaster_id` bigint(20) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

INSERT INTO `supplies` (`id`, `supply_name`, `supply_amount`, `lat`, `lng`, `disaster_id`, `address`) VALUES
(10,	'Water',	'low',	28.590164,	-81.236378,	1,	'10348-10402 Buck Rd, Orlando, FL 32817, USA'),
(11,	'Bread',	'high',	28.594987,	-81.358601,	1,	'733 W Lyman Ave, Winter Park, FL 32789, USA'),
(12,	'Canned vegetables',	'none',	28.523369,	-81.383492,	1,	'1600 Atlanta Ave, Orlando, FL 32806, USA'),
(13,	'Milk',	'high',	28.496066,	-81.233631,	1,	'5393 Young Pine Rd, Orlando, FL 32829, USA'),
(14,	'Gasoline',	'none',	28.584134,	-81.423145,	1,	'3204 Eunice Ave, Orlando, FL 32808, USA'),
(15,	'Charcoal',	'low',	28.487618,	-81.303669,	1,	'3590 Manatee St, Orlando, FL 32822, USA'),
(16,	'Jalepenos',	'high',	28.535887,	-81.443745,	1,	'4838 Huppel Ave, Orlando, FL 32811, USA'),
(17,	'Bread',	'low',	28.525330,	-81.351906,	1,	'1400 S Bumby Ave, Orlando, FL 32806, USA'),
(18,	'Apples',	'low',	28.690201,	-81.401173,	1,	'109 Butternut Ln, Longwood, FL 32779, USA');

DROP TABLE IF EXISTS `user`;
CREATE TABLE `user` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `email` varchar(255) DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `first_name` varchar(20) DEFAULT NULL,
  `last_name` varchar(20) DEFAULT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `id_UNIQUE` (`id`),
  UNIQUE KEY `email_UNIQUE` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;


-- 2018-08-11 04:15:55
